﻿using AssociationBids.Portal.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace AssociationBids.Portal.Controllers
{
    public class PMVendorController : Controller
    {
        private readonly AssociationBids.Portal.Service.Base.Interface.IPMVendorService __vendorservice;

        public PMVendorController(AssociationBids.Portal.Service.Base.Interface.IPMVendorService vendorService)
        {
            this.__vendorservice = vendorService;
        }

        // GET: Vendor
        public ActionResult PMVendorlist()
        {
            IList<VendorModel> lstservice = null;
            IList<VendorModel> lstproperty = null;

            //Service

            lstservice = __vendorservice.GetAllService();
            List<System.Web.Mvc.SelectListItem> lstservicelist = new List<System.Web.Mvc.SelectListItem>();

            for (int i = 0; i < lstservice.Count; i++)
            {
                System.Web.Mvc.SelectListItem sli = new System.Web.Mvc.SelectListItem();
                sli.Text = Convert.ToString(lstservice[i].ServiceTitle1);
                sli.Value = Convert.ToString(lstservice[i].ServiceKey);
                lstservicelist.Add(sli);
            }
            ViewBag.lstservice = lstservicelist;

            ////Property
            lstproperty = __vendorservice.GetAllProperty();
            List<System.Web.Mvc.SelectListItem> lstpropertylist = new List<System.Web.Mvc.SelectListItem>();

            for (int i = 0; i < lstproperty.Count; i++)
            {
                System.Web.Mvc.SelectListItem sli = new System.Web.Mvc.SelectListItem();
                sli.Text = Convert.ToString(lstproperty[i].Title);
                sli.Value = Convert.ToString(lstproperty[i].PropertyKey);
                lstpropertylist.Add(sli);
            }
            ViewBag.lstproperty = lstpropertylist;
            return View();
        }
        public JsonResult IndexvendorPaging(Int64 PageSize, Int64 PageIndex, string Search, String Sort)
        {
            IList<VendorModel> itemList = null;
            itemList = __vendorservice.SearchVendor(PageSize, PageIndex, Search.Trim(), Sort);
            return Json(itemList, JsonRequestBehavior.AllowGet);
        }

   
        // GET: AddVendor
        public ActionResult PMVendorAdd()
        {
            try
            {
        
                 IList<VendorModel> lststate = null;
                //list of state
                lststate = __vendorservice.GetAllState();
                List<System.Web.Mvc.SelectListItem> lststatelist = new List<System.Web.Mvc.SelectListItem>();
                System.Web.Mvc.SelectListItem sli2 = new System.Web.Mvc.SelectListItem();
                sli2.Text = "--Please Select--";
                sli2.Value = "0";
                lststatelist.Add(sli2);
                for (int i = 0; i < lststate.Count; i++)
                {
                    System.Web.Mvc.SelectListItem sli = new System.Web.Mvc.SelectListItem();
                    sli.Text = Convert.ToString(lststate[i].State);
                    sli.Value = Convert.ToString(lststate[i].StateKey);
                    lststatelist.Add(sli);
                }
                ViewBag.lststate = lststatelist;
              
            }
            catch (Exception ex)
            {
                Common.Error.WriteErrorsToFile(ex.Message.ToString());
                return View();
            }

            return View();
        }

        [HttpPost]
        public ActionResult PMVendorAdd(VendorModel collection)
        {
            try
            {
                Int64 value = 0;
                bool ErrorMsg = __vendorservice.CheckDuplicatedEmail(collection.Email);
                if (ErrorMsg != true)
                {
                    value = __vendorservice.Insert(collection);
                    if (value != 0)
                    {
                        TempData["Sucessmessage"] = "Record has been inserted successfully.";
                    }
                    else
                    {
                        ViewData["Errormessage"] = "Error";
                    }


                    return RedirectToAction("PMVendorlist");
                }

                else
                {
                    IList<VendorModel> lststate = null;
                    //list of state
                    lststate = __vendorservice.GetAllState();
                    List<System.Web.Mvc.SelectListItem> lststatelist = new List<System.Web.Mvc.SelectListItem>();
                    System.Web.Mvc.SelectListItem sli2 = new System.Web.Mvc.SelectListItem();
                    sli2.Text = "--Please Select--";
                    sli2.Value = "0";
                    lststatelist.Add(sli2);
                    for (int i = 0; i < lststate.Count; i++)
                    {
                        System.Web.Mvc.SelectListItem sli = new System.Web.Mvc.SelectListItem();
                        sli.Text = Convert.ToString(lststate[i].State);
                        sli.Value = Convert.ToString(lststate[i].StateKey);
                        lststatelist.Add(sli);
                    }
                    ViewBag.lststate = lststatelist;
                    ViewBag.ErrorMessage = "Email are Already Exists";

                    return View(collection);
                }

            }
            catch (Exception ex)
            {
                Common.Error.WriteErrorsToFile(ex.Message.ToString());
                return View("PMVendorlist");
            }
        }

        // GET: EditVendor
        public ActionResult PMVendorEdit(int CompanyKey)
        {
            try
            {
                IList<VendorModel> lststate = null;
                IList<VendorModel> lstservice = null;

                //Service

                lstservice = __vendorservice.GetAllService();
                List<System.Web.Mvc.SelectListItem> lstservicelist = new List<System.Web.Mvc.SelectListItem>();

                for (int i = 0; i < lstservice.Count; i++)
                {
                    System.Web.Mvc.SelectListItem sli = new System.Web.Mvc.SelectListItem();
                    sli.Text = Convert.ToString(lstservice[i].ServiceTitle1);
                    sli.Value = Convert.ToString(lstservice[i].ServiceKey);
                    lstservicelist.Add(sli);
                }
                ViewBag.lstservice = lstservicelist;

                //list of state
                lststate = __vendorservice.GetAllState();
                List<System.Web.Mvc.SelectListItem> lststatelist = new List<System.Web.Mvc.SelectListItem>();
                System.Web.Mvc.SelectListItem sli2 = new System.Web.Mvc.SelectListItem();
                sli2.Text = "--Please Select--";
                sli2.Value = "0";
                lststatelist.Add(sli2);
                for (int i = 0; i < lststate.Count; i++)
                {
                    System.Web.Mvc.SelectListItem sli = new System.Web.Mvc.SelectListItem();
                    sli.Text = Convert.ToString(lststate[i].State);
                    sli.Value = Convert.ToString(lststate[i].StateKey);
                    lststatelist.Add(sli);
                }
                ViewBag.lststate = lststatelist;
                VendorModel resources = null;
                resources = __vendorservice.GetDataViewEdit(CompanyKey);
                return View(resources);
            }
            catch (Exception ex)
            {
                return RedirectToAction("PMVendorlist");
            }
        }

        [HttpPost]
        public ActionResult PMVendorEdit(int CompanyKey, VendorModel collection)
        {
            VendorModel vendorv = new VendorModel();
            try
            {
                
                Int64 value = 0;
                value = __vendorservice.VendorEdit(collection);
                if (value == 0)
                {
                    TempData["Sucessmessage"] = "Record has been updated successfully.";
                    return RedirectToAction("PMVendorlist");
                }
                else
                {
                    ViewData["Errormessage"] = "Error";
                    return RedirectToAction("PMVendorEdit");

                }  

            }
            catch (Exception ex)
            {
                return View(vendorv);

            }

        }


        // GET: Viewvendor
        public ActionResult VendorView(int CompanyKey)
        {
            VendorModel vendorv = new VendorModel();

            try
            {
                IList<VendorModel> lstservice = null;
                VendorModel vendor = new VendorModel();
               

                //Service

                lstservice = __vendorservice.GetAllService();
                List<System.Web.Mvc.SelectListItem> lstservicelist = new List<System.Web.Mvc.SelectListItem>();

                for (int i = 0; i < lstservice.Count; i++)
                {
                    System.Web.Mvc.SelectListItem sli = new System.Web.Mvc.SelectListItem();
                    sli.Text = Convert.ToString(lstservice[i].ServiceTitle1);
                    sli.Value = Convert.ToString(lstservice[i].ServiceKey);
                    lstservicelist.Add(sli);
                }
                ViewBag.lstservice = lstservicelist;
                vendor = __vendorservice.GetDataViewEdit(CompanyKey);
                if (vendor != null)
                {
                    return View(vendor);
                }
                else
                {
                    return View(vendorv);

                }

              
            }
            catch(Exception ex)
            {
                Common.Error.WriteErrorsToFile(ex.Message.ToString());
                return View(vendorv);
            }

        }

        public JsonResult IndexinsurancePaging(int CompanyKey)
        {
            try
            {
                IList<VendorModel> itemList = null;
                itemList = __vendorservice.Searchinsurance(CompanyKey);
                return Json(itemList, JsonRequestBehavior.AllowGet);
            }
            catch(Exception ex)
            {
                return Json(null);
            }
        }

        public JsonResult bindservice(int CompanyKey)
        {
            try
            {
                IList<VendorModel> servicelist = null;
                servicelist = __vendorservice.Getbindservice(CompanyKey);
                return Json(servicelist, JsonRequestBehavior.AllowGet);

            }
            catch
            {
                return Json(null);
            }
        }

        public JsonResult bindDocument(int CompanyKey)
        {
            try
            {
                IList<VendorModel> Documentlist = null;
        
                Documentlist = __vendorservice.GetbindDocument(CompanyKey);
                return Json(Documentlist, JsonRequestBehavior.AllowGet);

            }
            catch
            {
                return Json(null);
            }
        }
        public ActionResult Delete(int CompanyKey)
        {

            bool Status = false;
            Status = __vendorservice.Remove(CompanyKey);
            if(Status == true)
            {
                TempData["Sucessmessage"] = "Record has been deleted successfully.";
                return RedirectToAction("PMVendorlist", "PMVendor");
            }
            else
            {
                ViewData["Errormessage"] = "Error";
                return RedirectToAction("PMVendorlist", "PMVendor");
            }
            
        }

        public ActionResult DeleteService(int CompanyKey, string servicename)
        {
            try
            {
                bool Status = false;
                Status = __vendorservice.RemoveService(CompanyKey,servicename);
                return RedirectToAction("VendorView", new { CompanyKey = CompanyKey });
            }
            catch (Exception ex)
            {
                return RedirectToAction("VendorView", new { CompanyKey = CompanyKey });
            }

        }
        public ActionResult Deletedocument(int CompanyKey, int documentid)
        {
            try
            {
                bool Status = false;
                Status = __vendorservice.RemoveDocument(CompanyKey, documentid);
                return RedirectToAction("VendorView", new { CompanyKey = CompanyKey });
            }
            catch (Exception ex)
            {
                return RedirectToAction("VendorView", new { CompanyKey = CompanyKey });
            }

        }


    }
}